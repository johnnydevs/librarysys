$(document).ready(function() {

    // your stuff here
    // ...

});
