<div class="container">
    
    <div class="row">
    
    <h1>Dashboard</h1>

    <!-- echo out the system feedback (error and success messages) -->
    <?php $this->renderFeedbackMessages(); ?>

    <h3>Welcome <?php echo Session::get('user_name'); ?>.</h3>

    <p>Some more text here.</p>
    <p>Some more text here.</p>
    <p>Some more text here.</p>
    <p>Some more text here.</p>
    
    </div>
    
</div>
