<div class="container">

    <div class="row">
    
    <!-- echo out the system feedback (error and success messages) -->
    <?php $this->renderFeedbackMessages(); ?>

    <h1>AdminArea</h1>
    
    </div>


</div>