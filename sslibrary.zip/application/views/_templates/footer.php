<!-- See CSS file for link to Font Awsome CSS 

Reference:
http://lipis.github.io/bootstrap-social
http://fortawesome.github.io/Font-Awesome/icons/

-->

<div class="container">
    <div class="row">

    <hr>

        <div class="text-center">
        <hr>
            <!-- just add href= for your links, like this: -->
            <a href="http://www.facebook.com/LittleHandsSureStart" target="_blank" class="btn btn-social-icon btn-facebook"><i class="fa fa-2x fa-facebook"></i></a>    
            <a href="http://www.twitter.com/lhss" target="_blank" class="btn btn-social-icon btn-twitter"><i class="fa fa-2x fa-twitter"></i></a>
            <a href="http://www.youtube.com/LHSureStart" target="_blank" class="btn btn-social-icon btn-youtube"><i class="fa fa-2x fa-youtube"></i></a>
            <a href="http://www.littlehandssurestart.co.uk" target="_blank" class="btn btn-social-icon btn-desktop"><i class="fa fa-2x fa-desktop"></i></a>

        </div>
    
        <div class="text-center">
            <a href="http://www.johnnyshongo.com" target="_blank" class="btn btn-social-icon btn-desktop"><i class="fa fa-copyright"></i> JShongoDesign</a>
        </div>


    </div> <!-- /.row -->
</div> <!-- /.container -->



</body>
</html>
