<div class="content">
    <h1 style="color: red;">
        This page does not exist.
    </h1>
</div>
